"""Settings loaded from environment variables only (never from code)."""
from __future__ import annotations

import os
from dataclasses import dataclass, field

from cryptography.fernet import Fernet


class ConfigError(RuntimeError):
    """Raised when required configuration is missing or invalid."""


@dataclass(frozen=True)
class Settings:
    env: str = "development"
    database_url: str = field(default="", repr=False)
    encryption_keys: tuple = field(default=(), repr=False)  # never print keys
    gemini_api_key: str = field(default="", repr=False)
    gemini_model: str = "gemini-2.5-flash"
    test_token: str = field(default="", repr=False)

    @property
    def is_production(self) -> bool:
        return self.env == "production"


def _parse_keys(raw: str) -> tuple:
    keys = tuple(k.strip() for k in raw.split(",") if k.strip())
    for k in keys:
        try:
            Fernet(k.encode())
        except Exception as exc:  # invalid base64 / wrong length
            raise ConfigError(
                "NEXUS_ENCRYPTION_KEYS contains an invalid key. "
                "Generate one with Fernet.generate_key()."
            ) from exc
    return keys


def load_settings(environ=None) -> Settings:
    e = os.environ if environ is None else environ
    env = e.get("NEXUS_ENV", "development").strip().lower()
    if env not in {"development", "production"}:
        raise ConfigError("NEXUS_ENV must be 'development' or 'production'.")

    keys = _parse_keys(e.get("NEXUS_ENCRYPTION_KEYS", ""))
    if env == "production" and not keys:
        raise ConfigError("NEXUS_ENCRYPTION_KEYS is required in production.")

    db = e.get("DATABASE_URL", "").strip()
    if env == "production" and not db:
        raise ConfigError("DATABASE_URL is required in production.")

    return Settings(
        env=env,
        database_url=db,
        encryption_keys=keys,
        gemini_api_key=e.get("GEMINI_API_KEY", "").strip(),
        gemini_model=e.get("GEMINI_MODEL", "gemini-2.5-flash").strip(),
        test_token=e.get("NEXUS_TEST_TOKEN", "").strip(),
    )
