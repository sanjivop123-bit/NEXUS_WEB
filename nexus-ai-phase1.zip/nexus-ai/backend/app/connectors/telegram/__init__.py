"""telegram connector. Not implemented yet."""
