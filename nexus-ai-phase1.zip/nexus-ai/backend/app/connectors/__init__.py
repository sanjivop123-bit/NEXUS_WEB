"""One module per connector (GitHub, Drive, Telegram, Render, Browser, Postgres). Added from Phase 3."""
