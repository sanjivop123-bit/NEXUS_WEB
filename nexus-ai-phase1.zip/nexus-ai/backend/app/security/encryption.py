"""Encrypt customer credentials (GitHub / Google tokens etc.) before they touch the database.

Design:
- Fernet (AES-128-CBC + HMAC) from the `cryptography` library - no home-made crypto.
- MultiFernet allows key rotation: first key encrypts, every key can decrypt.
- Each secret is bound to (user_id, connector). If someone copies user A's
  encrypted token into user B's row, decryption FAILS. This stops cross-customer leaks.
"""
from __future__ import annotations

import json

from cryptography.fernet import Fernet, InvalidToken, MultiFernet


class CredentialError(Exception):
    """Decryption failed or the secret does not belong to this user/connector."""


class CredentialVault:
    def __init__(self, keys):
        if not keys:
            raise CredentialError("No encryption key configured.")
        self._fernet = MultiFernet([Fernet(k.encode()) for k in keys])

    def encrypt(self, user_id: str, connector: str, secret: str) -> str:
        envelope = json.dumps({"u": user_id, "c": connector, "v": secret})
        return self._fernet.encrypt(envelope.encode()).decode()

    def decrypt(self, user_id: str, connector: str, token: str) -> str:
        try:
            data = json.loads(self._fernet.decrypt(token.encode()))
        except (InvalidToken, ValueError) as exc:
            raise CredentialError("Could not decrypt credential.") from exc
        if data.get("u") != user_id or data.get("c") != connector:
            raise CredentialError("Credential does not belong to this user/connector.")
        return data["v"]

    def rotate(self, token: str) -> str:
        """Re-encrypt an existing token with the newest key."""
        try:
            return self._fernet.rotate(token.encode()).decode()
        except InvalidToken as exc:
            raise CredentialError("Could not rotate credential.") from exc
