"""Approval policy: which agent actions need an explicit human OK.

The AI model can only *request* an action. This code decides.
Every connector tool must declare an ActionCategory (Phase 2 registry enforces it).
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class ActionCategory(str, Enum):
    READ = "read"                              # list repos, read a file - no approval
    SEND_EXTERNAL_MESSAGE = "send_external"    # Telegram, email
    DELETE = "delete"                          # delete files / data
    WRITE_REPO = "write_repo"                  # commit, push, open PR, edit files
    DEPLOY_PRODUCTION = "deploy_production"    # trigger Render deploy, env change
    SHELL = "shell"                            # arbitrary shell command - NEVER allowed


NEEDS_APPROVAL = {
    ActionCategory.SEND_EXTERNAL_MESSAGE,
    ActionCategory.DELETE,
    ActionCategory.WRITE_REPO,
    ActionCategory.DEPLOY_PRODUCTION,
}


@dataclass(frozen=True)
class Decision:
    allowed: bool
    needs_user_approval: bool
    reason: str


def evaluate(category: ActionCategory, user_approved: bool = False) -> Decision:
    if category is ActionCategory.SHELL:
        return Decision(False, False, "Arbitrary shell commands are not allowed.")
    if category in NEEDS_APPROVAL:
        if user_approved:
            return Decision(True, False, "Approved by user.")
        return Decision(False, True, "Waiting for explicit user approval.")
    return Decision(True, False, "Read-only action.")
