"""Security helpers: credential encryption, approval policy (Phase 1)."""
