"""NEXUS AI backend entry point.

Run locally:   uvicorn app.main:app --reload
"""
from fastapi import FastAPI

from app.api import chat, health
from app.config import load_settings

settings = load_settings()

app = FastAPI(
    title="NEXUS AI",
    version="0.1.0",
    # Hide interactive docs in production so the API surface is not advertised.
    docs_url=None if settings.is_production else "/docs",
    redoc_url=None,
    openapi_url=None if settings.is_production else "/openapi.json",
)
app.state.settings = settings
app.include_router(health.router)
app.include_router(chat.router)
