"""LangGraph agent loop. Not implemented yet (after Phase 2)."""
