"""Chooses the AI provider. Only Gemini is wired now; Anthropic/OpenAI are added later."""
from __future__ import annotations

from app.agents import gemini
from app.agents.gemini import ModelError


async def reply(settings, message: str, provider: str = "gemini") -> str:
    if provider == "gemini":
        if not settings.gemini_api_key:
            raise ModelError("GEMINI_API_KEY is not set on the server.")
        return await gemini.generate(settings.gemini_api_key, settings.gemini_model, message)
    raise ModelError(f"Provider '{provider}' is not enabled yet.")
