"""Gemini adapter (direct REST, standard library only). The API key stays on the server."""
from __future__ import annotations

import asyncio
import json
import urllib.error
import urllib.request

BASE = "https://generativelanguage.googleapis.com/v1beta/models"


class ModelError(Exception):
    """Safe-to-show error. Never contains the API key."""


def build_request(api_key: str, model: str, message: str) -> urllib.request.Request:
    body = {"contents": [{"role": "user", "parts": [{"text": message}]}]}
    return urllib.request.Request(
        f"{BASE}/{model}:generateContent",
        data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json", "x-goog-api-key": api_key},
        method="POST",
    )


def parse_reply(data: dict) -> str:
    try:
        parts = data["candidates"][0]["content"]["parts"]
        text = "".join(p.get("text", "") for p in parts).strip()
    except (KeyError, IndexError, TypeError):
        raise ModelError("Gemini returned no answer (it may have been blocked).")
    if not text:
        raise ModelError("Gemini returned an empty answer.")
    return text


def _call(api_key: str, model: str, message: str, timeout: float, opener) -> str:
    req = build_request(api_key, model, message)
    try:
        with opener(req, timeout=timeout) as resp:
            return parse_reply(json.loads(resp.read()))
    except urllib.error.HTTPError as e:
        if e.code in (400, 401, 403):
            raise ModelError("Gemini rejected the request. Check GEMINI_API_KEY and GEMINI_MODEL on Render.")
        if e.code == 429:
            raise ModelError("Gemini rate limit reached. Try again shortly.")
        raise ModelError(f"Gemini error (HTTP {e.code}).")
    except (urllib.error.URLError, TimeoutError):
        raise ModelError("Could not reach Gemini (network or timeout).")


async def generate(api_key: str, model: str, message: str, timeout: float = 30.0, opener=urllib.request.urlopen) -> str:
    return await asyncio.to_thread(_call, api_key, model, message, timeout, opener)
