"""Health check for Render. Must never return secrets."""
from fastapi import APIRouter, Request

router = APIRouter()


@router.get("/health")
def health(request: Request) -> dict:
    app = request.app
    return {"status": "ok", "environment": app.state.settings.env, "version": app.version}
