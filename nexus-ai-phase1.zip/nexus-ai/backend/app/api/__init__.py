"""Public HTTP routes used by the Android app."""
