"""Chat endpoint. TEMPORARY protection: shared test token. Real user login comes in Phase 7."""
import hmac
from typing import Optional

from fastapi import APIRouter, Header, HTTPException, Request
from pydantic import BaseModel, Field

from app.agents import model_router
from app.agents.gemini import ModelError

router = APIRouter()


class ChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=4000)


@router.post("/chat")
async def chat(body: ChatIn, request: Request, x_nexus_test_token: Optional[str] = Header(default=None)):
    s = request.app.state.settings
    if s.test_token:
        if not hmac.compare_digest(x_nexus_test_token or "", s.test_token):
            raise HTTPException(401, "Invalid test token.")
    elif s.is_production:
        raise HTTPException(503, "Set NEXUS_TEST_TOKEN on the server to enable /chat.")
    try:
        text = await model_router.reply(s, body.message)
    except ModelError as e:
        raise HTTPException(502, str(e))
    return {"reply": text, "provider": "gemini"}
