"""Connector registry. Phase 2."""
