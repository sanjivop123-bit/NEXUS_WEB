"""MCP client: independent server connections, timeouts, health checks. Phase 2."""
