"""Tool discovery and registration. Phase 2."""
