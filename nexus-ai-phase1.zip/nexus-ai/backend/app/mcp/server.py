"""NEXUS's own MCP server - built only if we need one."""
