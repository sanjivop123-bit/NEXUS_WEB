"""MCP client, connection manager, tool discovery. Added in Phase 2."""
