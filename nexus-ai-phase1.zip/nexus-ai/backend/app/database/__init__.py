"""PostgreSQL models, audit log, usage counters. Phase 7."""
