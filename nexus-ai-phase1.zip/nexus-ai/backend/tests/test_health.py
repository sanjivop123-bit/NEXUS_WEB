import unittest

try:
    from fastapi.testclient import TestClient
    from app.main import app
    HAVE_FASTAPI = True
except ImportError:  # fastapi/httpx not installed yet
    HAVE_FASTAPI = False


@unittest.skipUnless(HAVE_FASTAPI, "fastapi + httpx not installed")
class HealthTests(unittest.TestCase):
    def test_health_ok_and_no_secrets(self):
        r = TestClient(app).get("/health")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["status"], "ok")
        self.assertNotIn("key", r.text.lower())


if __name__ == "__main__":
    unittest.main()
