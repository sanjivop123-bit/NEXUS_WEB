import io
import json
import unittest
import urllib.error

from app.agents import gemini
from app.agents.gemini import ModelError


class FakeResp(io.BytesIO):
    def __enter__(self): return self
    def __exit__(self, *a): return False


def ok_opener(payload):
    def opener(req, timeout):
        opener.req = req
        return FakeResp(json.dumps(payload).encode())
    return opener


def err_opener(code):
    def opener(req, timeout):
        raise urllib.error.HTTPError(req.full_url, code, "x", {}, None)
    return opener


class GeminiTests(unittest.TestCase):
    def test_request_shape_and_key_in_header_not_url(self):
        r = gemini.build_request("KEY123", "gemini-x", "hello")
        self.assertNotIn("KEY123", r.full_url)
        self.assertEqual(r.get_header("X-goog-api-key"), "KEY123")
        self.assertEqual(json.loads(r.data)["contents"][0]["parts"][0]["text"], "hello")

    def test_success(self):
        op = ok_opener({"candidates": [{"content": {"parts": [{"text": "Vanakkam"}]}}]})
        self.assertEqual(gemini._call("k", "m", "hi", 5, op), "Vanakkam")

    def test_blocked_or_empty(self):
        with self.assertRaises(ModelError):
            gemini._call("k", "m", "hi", 5, ok_opener({"candidates": []}))

    def test_errors_hide_key(self):
        for code in (400, 403, 429, 500):
            with self.assertRaises(ModelError) as c:
                gemini._call("SECRETKEY", "m", "hi", 5, err_opener(code))
            self.assertNotIn("SECRETKEY", str(c.exception))

    def test_network_error(self):
        def op(req, timeout): raise urllib.error.URLError("down")
        with self.assertRaises(ModelError):
            gemini._call("k", "m", "hi", 5, op)


if __name__ == "__main__":
    unittest.main()
