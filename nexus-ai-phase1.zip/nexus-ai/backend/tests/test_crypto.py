import unittest

from cryptography.fernet import Fernet

from app.security.encryption import CredentialError, CredentialVault


class VaultTests(unittest.TestCase):
    def setUp(self):
        self.k1 = Fernet.generate_key().decode()
        self.k2 = Fernet.generate_key().decode()
        self.vault = CredentialVault([self.k1])

    def test_roundtrip(self):
        t = self.vault.encrypt("user-1", "github", "ghp_secret")
        self.assertNotIn("ghp_secret", t)
        self.assertEqual(self.vault.decrypt("user-1", "github", t), "ghp_secret")

    def test_other_user_cannot_use_token(self):
        t = self.vault.encrypt("user-1", "github", "ghp_secret")
        with self.assertRaises(CredentialError):
            self.vault.decrypt("user-2", "github", t)

    def test_other_connector_cannot_use_token(self):
        t = self.vault.encrypt("user-1", "github", "ghp_secret")
        with self.assertRaises(CredentialError):
            self.vault.decrypt("user-1", "gdrive", t)

    def test_wrong_key_fails(self):
        t = self.vault.encrypt("user-1", "github", "x")
        with self.assertRaises(CredentialError):
            CredentialVault([self.k2]).decrypt("user-1", "github", t)

    def test_garbage_fails(self):
        with self.assertRaises(CredentialError):
            self.vault.decrypt("user-1", "github", "garbage")

    def test_key_rotation(self):
        old = self.vault.encrypt("u", "github", "secret")
        new = CredentialVault([self.k2, self.k1]).rotate(old)
        self.assertEqual(CredentialVault([self.k2]).decrypt("u", "github", new), "secret")

    def test_no_keys_rejected(self):
        with self.assertRaises(CredentialError):
            CredentialVault([])


if __name__ == "__main__":
    unittest.main()
