import unittest

from app.security.permissions import ActionCategory as A
from app.security.permissions import evaluate

RISKY = (A.SEND_EXTERNAL_MESSAGE, A.DELETE, A.WRITE_REPO, A.DEPLOY_PRODUCTION)


class ApprovalTests(unittest.TestCase):
    def test_read_is_allowed(self):
        self.assertTrue(evaluate(A.READ).allowed)

    def test_risky_actions_blocked_without_approval(self):
        for cat in RISKY:
            d = evaluate(cat)
            self.assertFalse(d.allowed, cat)
            self.assertTrue(d.needs_user_approval, cat)

    def test_risky_actions_allowed_after_approval(self):
        for cat in RISKY:
            self.assertTrue(evaluate(cat, user_approved=True).allowed, cat)

    def test_shell_never_allowed_even_if_approved(self):
        d = evaluate(A.SHELL, user_approved=True)
        self.assertFalse(d.allowed)
        self.assertFalse(d.needs_user_approval)


if __name__ == "__main__":
    unittest.main()
