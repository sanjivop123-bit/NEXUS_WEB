import unittest

from cryptography.fernet import Fernet

from app.config import ConfigError, load_settings


class ConfigTests(unittest.TestCase):
    def test_defaults_to_development(self):
        self.assertEqual(load_settings({}).env, "development")

    def test_production_requires_keys_and_db(self):
        with self.assertRaises(ConfigError):
            load_settings({"NEXUS_ENV": "production"})
        with self.assertRaises(ConfigError):
            load_settings({"NEXUS_ENV": "production",
                           "NEXUS_ENCRYPTION_KEYS": Fernet.generate_key().decode()})

    def test_production_ok(self):
        s = load_settings({"NEXUS_ENV": "production", "DATABASE_URL": "postgresql://x",
                           "NEXUS_ENCRYPTION_KEYS": Fernet.generate_key().decode()})
        self.assertTrue(s.is_production)

    def test_invalid_key_rejected(self):
        with self.assertRaises(ConfigError):
            load_settings({"NEXUS_ENCRYPTION_KEYS": "not-a-key"})

    def test_keys_not_in_repr(self):
        key = Fernet.generate_key().decode()
        self.assertNotIn(key, repr(load_settings({"NEXUS_ENCRYPTION_KEYS": key})))

    def test_bad_env_rejected(self):
        with self.assertRaises(ConfigError):
            load_settings({"NEXUS_ENV": "staging"})


if __name__ == "__main__":
    unittest.main()
