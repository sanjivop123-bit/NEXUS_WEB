# NEXUS AI - Security design (Phase 1)

## Secrets
- No API key, token or secret in the Android app or in Git. `.env` is git-ignored; production values live in Render Environment settings.
- `.env.example` contains names only, never values.
- Customer tokens (GitHub, Google) are encrypted with Fernet (`app/security/encryption.py`) before saving to PostgreSQL.
- Each encrypted token is bound to `(user_id, connector)`; copying it to another user's row makes decryption fail.
- Key rotation: set `NEXUS_ENCRYPTION_KEYS=newkey,oldkey`, re-encrypt, then remove the old key.
- Secrets never go in logs, error messages or `/health`.

## Customer isolation
- Separate OAuth consent per customer for GitHub and Google Drive.
- Connections keyed by `(user_id, connector_id)`; no shared sessions or caches across users.
- Least privilege: GitHub starts read-only; Drive uses the narrowest scope that works.

## Approval gate (`app/security/permissions.py`)
Needs explicit user approval: sending external messages, deleting files, writing to repositories, deploying production.
Arbitrary shell commands are always denied, even with approval.
The model can only request; backend code decides.

## Later phases
- Audit log of every tool call (who, what, when, result) - Phase 7.
- Rate limits and subscription tool limits - Phase 7.
- Browser automation in an isolated sandbox with no shell and no access to NEXUS secrets - Phase 6.
- Production hides `/docs` and `/openapi.json`.

## Known limits of Phase 1
Design and building blocks only: no login, database or connectors yet.
