# NEXUS AI - Architecture (Phase 1)

## Big picture
```
Android app (Expo RN + TS)
   |  HTTPS + user login token (no AI keys, no third-party keys inside the app)
   v
FastAPI backend (Render)  ---- PostgreSQL (users, encrypted credentials, audit log, usage)
   |
   +-- Agent layer (LangGraph)  --> Claude / OpenAI / Gemini adapters
   |
   +-- Policy layer: auth -> subscription limits -> rate limit -> approval gate -> audit log
   |
   +-- Connector registry
         |-- MCP connectors  (via our MCP client; each = its own independent connection)
         |-- REST connectors (direct API calls when no good MCP server exists)
         |-- NEXUS MCP server (only if we need to expose our own tools)
```

## Key rules
1. The Android app only talks to OUR backend. All third-party keys live on the server.
2. Every tool call passes the policy layer BEFORE reaching a connector.
3. A connection is identified by `(user_id, connector_id)`. One customer's GitHub/Drive session is never reused for another customer.
4. MCP does not remove the need for API keys, OAuth or permissions; it only standardises how tools are described and called.

## Connector plan (MCP vs REST)
"Verify" = I must confirm the server is current and maintained before we depend on it (done in that connector's phase).

| Connector | Plan | Auth | Phase |
|---|---|---|---|
| GitHub | Official GitHub MCP server if it fits; else REST | Per-customer OAuth, read-only scopes first | 3 |
| Google Drive | Direct REST (Drive API); MCP only if a maintained server is verified | Per-customer Google OAuth, narrowest scope | 4 |
| Telegram | Direct REST (Bot API) | Bot token on server; sends need approval | 5 |
| Render | Official Render MCP server or REST (verify) | Render API key; deploys need approval | 5 |
| Browser | Playwright-based MCP server inside an isolated container (verify) | None, but sandboxed, no shell | 6 |
| PostgreSQL | Direct read-only DB role via our own code | Separate read-only DB user | later |
| Future | Add via registry config, no core code change | per server | any |

## Backend folders (created in Phase 1)
```
backend/app/
  main.py        FastAPI app + /health
  config.py      settings from environment variables
  security/      encryption.py (credential vault), permissions.py (approval policy), auth.py (Phase 7)
  mcp/           MCP client + connection manager      (Phase 2)
  connectors/    one module per connector             (Phase 3+)
  agents/        LangGraph + model adapters           (later)
  database/      models, audit log, usage             (Phase 7)
```

## Connector interface (implemented in Phase 2)
Each tool carries: `name`, `description`, `input_schema`, `ActionCategory` (read / send_external / delete / write_repo / deploy_production), and `min_plan` (subscription tier).
The registry rejects any tool without a category, so nothing can skip approval by accident.

## Planned database tables (built in Phase 7, sketch only)
`users`, `subscriptions`, `connector_accounts` (encrypted token column), `tool_calls_audit`, `usage_counters`, `pending_approvals`.
