# NEXUS AI

Secure multi-model AI agent platform for Android (Claude, OpenAI, Gemini) with MCP-based connectors.

- `docs/ARCHITECTURE.md` - how the pieces fit together
- `docs/SECURITY.md` - security design and rules
- `backend/` - FastAPI backend (Python)

## Run Phase 1 locally
```
cd backend
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env             # then fill .env (never commit it)
python -m pytest                 # run tests
uvicorn app.main:app --reload    # open http://localhost:8000/health
```
